/*
 * AirtimaActivity
 *
 * This activity provides a simplified user interface inspired by the user's
 * Airtima Mobile VPN prototype.  It presents an editable field for entering
 * a custom SNI host, a drop‑down for choosing the type of bundle, and a
 * connect/disconnect button.  Connection status and byte counters are
 * displayed at the top of the screen.
 *
 * NOTE: The byte counters currently update placeholders only.  Integrating
 * real traffic statistics would require changes to the underlying
 * PowerTunnelService implementation.
 */
package io.github.krlvm.powertunnel.android.activities;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import io.github.krlvm.powertunnel.android.R;
import io.github.krlvm.powertunnel.android.services.PowerTunnelService;
import io.github.krlvm.powertunnel.android.types.GlobalStatus;

public class AirtimaActivity extends AppCompatActivity {

    private TextView statusDisconnected;
    private TextView statusConnected;
    private TextView tvOutBytes;
    private TextView tvInBytes;
    private EditText editSniHost;
    private Spinner spinnerConnection;
    private Button connectButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.airtima_activity);

        statusDisconnected = findViewById(R.id.status_disconnected);
        statusConnected = findViewById(R.id.status_connected);
        tvOutBytes = findViewById(R.id.tv_out_bytes);
        tvInBytes = findViewById(R.id.tv_in_bytes);
        editSniHost = findViewById(R.id.edit_sni_host);
        spinnerConnection = findViewById(R.id.spinner_connection);
        connectButton = findViewById(R.id.button_connect);

        // Restore previously entered SNI host if present
        final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String lastSni = prefs.getString("airtima_sni_host", "");
        if (lastSni != null) {
            editSniHost.setText(lastSni);
        }

        // Update initial UI state
        updateStatusUI();

        connectButton.setOnClickListener(v -> {
            if (PowerTunnelService.isRunning()) {
                PowerTunnelService.stopTunnel(AirtimaActivity.this);
                Toast.makeText(AirtimaActivity.this, R.string.action_disconnect, Toast.LENGTH_SHORT).show();
            } else {
                // Save SNI host selection for later use
                String sni = editSniHost.getText().toString().trim();
                prefs.edit().putString("airtima_sni_host", sni).apply();
                // Optionally, store the selected bundle type
                int selection = spinnerConnection.getSelectedItemPosition();
                prefs.edit().putInt("airtima_connection_index", selection).apply();
                // Start PowerTunnel with the current mode
                PowerTunnelService.startTunnel(AirtimaActivity.this);
                Toast.makeText(AirtimaActivity.this, R.string.action_connect, Toast.LENGTH_SHORT).show();
            }
            // Immediately update status UI after toggling
            updateStatusUI();
        });

        // When a connection option is selected, you could react here
        spinnerConnection.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Placeholder: you might adjust preferences based on bundle type here
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatusUI();
    }

    /**
     * Updates the UI elements to reflect whether the service is running or not.
     */
    private void updateStatusUI() {
        boolean running = PowerTunnelService.isRunning();
        statusConnected.setVisibility(running ? View.VISIBLE : View.INVISIBLE);
        statusDisconnected.setVisibility(running ? View.INVISIBLE : View.VISIBLE);
        // When connected, you could periodically update tvOutBytes and tvInBytes
        // with real traffic stats if available.
        connectButton.setText(running ? R.string.action_disconnect : R.string.airtima_connect);
    }
}